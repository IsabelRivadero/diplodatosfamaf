Notebooks que crean las animaciones de las filminas de clustering
