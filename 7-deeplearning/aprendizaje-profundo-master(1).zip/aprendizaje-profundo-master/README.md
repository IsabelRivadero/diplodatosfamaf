# aprendizaje-profundo
Diplomatura FAMAF 2019

Primer TP:
https://github.com/juan-analian/aprendizaje-profundo/blob/master/informe_tp_01.ipynb
